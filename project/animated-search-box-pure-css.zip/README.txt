A Pen created at CodePen.io. You can find this one at https://codepen.io/Gogh/pen/xbRmXy.

 Heres an animated search, mess around with the .hover properties and see what you can do. Tell me what you think!